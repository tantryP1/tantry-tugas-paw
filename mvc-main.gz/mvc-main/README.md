# This is what you'll get from the tutorial
### Main View = Item List
![](https://github.com/jalupriyangga/mvc/assets/113582491/79ea4714-c783-4007-b978-e074c0135c2f)

### Form View for Insert New Item and Update
I added an Item
![_](https://github.com/jalupriyangga/mvc/assets/113582491/5ebbbc3d-2c17-47ca-b903-fdde7b51acab)

### These are the results
I updated
![Web capture_26-10-2023_195936_localhost](https://github.com/jalupriyangga/mvc/assets/113582491/2813472e-272c-448e-bdd8-ef04f87c5970)
![Web capture_26-10-2023_203117_localhost](https://github.com/jalupriyangga/mvc/assets/113582491/ec2187b7-d558-4f9a-8eca-51150f68cc54)


I deleted
![](https://github.com/jalupriyangga/mvc/assets/113582491/79ea4714-c783-4007-b978-e074c0135c2f)
