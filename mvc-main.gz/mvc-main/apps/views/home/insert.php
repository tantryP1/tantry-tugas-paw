<?php

$this->loadview('home/form', $data);
?>