<ul>
    <li><?= $data['id'] ?></li>
    <li><?= $data['nama'] ?></li>
    <li><?= $data['qty'] ?></li>
</ul>