<?php

require_once ("apps/Boot.php");
$apps = new Boot();
    